# Xi Er

Xi Er is a Codex skill for planning, animating, narrating, and rendering short videos. The skill instructions are in [xi-er/SKILL.md](xi-er/SKILL.md). Keep the `xi-er` and `videokit` directories together when using this checkout.

The included videokit and original skill are based on [SiuZheng/make-video-skill](https://github.com/SiuZheng/make-video-skill), distributed under the included MIT license.
