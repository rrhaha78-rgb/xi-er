# The standing rules

They come from lessons learned on earlier videos; keep to them on every video unless the user says
otherwise.

- **Draft the story and shots before building.** If the user has already said to go or asked for no second review,
  continue through rendering without another approval pause.
- **Inspect the animatic and final cut.** Use the checklist in review.md yourself. Use a reviewer agent only
  if the user asks for one. Fix concrete defects, then deliver.
- **TikTok too:** when the user posts their Shorts on TikTok as well, where uploads look blurry, deliver
  the TikTok cut (`vk.py final --platform tiktok`) beside the YouTube file.
- **Use established preferences** when the user has already supplied format, voice, look, asset and music
  choices. Ask only for a missing decision that materially affects the video.
- **List asset sources in the draft.** Use generated images only when authorized for that project.
- **No Gemini billing by default.** The user repeatedly asked for no Gemini billing. Never enable it or
  assume paid Gemini generation. Use an available free narrator if the free Gemini tier cannot serve the voice.
- **Never print or paste the Gemini API key**, or write it to a file. It's in GEMINI_API_KEY (on Windows,
  also read from the registry).
- **"Just asking" means answer in words.** Questions about ideas, YouTube, money, or "how would you do X"
  get an answer, not a build. Build when they say go.
- **Songs:** never download songs from YouTube; the user supplies audio and lyrics. Never put another
  artist's lyrics on screen. For a Short with someone else's song, deliver the SFX-only cut; they add the
  song with YouTube's "Add sound".
- **1080p only:** deliver the 1920×1080 (or 1080×1920) file. No 720p "phone preview" copies.
- **Keep the old versions:** `vk.py final` moves the previous file to out/<name>-vN.mp4.
- **Every shot is alive.** A Short that scored 20/20 was still called too plain once it was watched in
  motion: the world sat still and only a few things moved. Lighting, effects and camera fixed it. Every
  shot gets:
  - a moving camera;
  - parallax depth;
  - a light you can see;
  - something besides the character moving.

  Build all of it from the first build, not as a fix after delivery (pro-look.md, "Make it rich").
- **The character is part of the story** - riding, standing on, pointing at, reacting to what's on screen;
  a character just floating around looks like filler.
- **TV-cartoon acting:** the character moves independently of the set with head, limb and pose changes
  appropriate to the action. Check motion at normal speed; a pan over a fixed pose is insufficient.
- **Facts are checked**, sources listed in youtube.md, date-dependent facts flagged.
- **AI voice disclosure:** the description credits the AI voice; tick "altered or synthetic content".
- **Language:** if they ask for Chinese-only (or any language), every on-screen word follows it.
- **Image-generation tools** (such as Gemini's Nano Banana) are used only when the user says so.
- After finishing, update the project's memory note so the next session knows what exists.
