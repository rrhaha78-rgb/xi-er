# Dimensional cartoon style

Use this when the user requests a dimensional cartoon. Carry the chosen look across the character, props, and environment.

## Visual styles

- **Textured cinematic 3D.** Match the look of [the user's six-panel reference](../assets/cinematic-3d-look.png). Use expressive stylized faces with believable anatomy, shaped hair with visible strands, clothing with seams and fabric texture, and materials that react differently to light. Build detailed sets with foreground, middle ground, and background, and use motivated warm and cool lighting and depth of field. Use the reference for the look of a shot. Take the story and shot choices from the user's brief.
- **Clay.** Keep this available when the user chooses it. Use rounded forms, simple shapes, soft matte surfaces, and a handcrafted look. The earlier clay test also serves as a motion reference regardless of the chosen visual style.

## Shared checks

- Use a rigged 3D character for cinema-style movement. `VolumetricCharacter` in `src/fx/volumetricCharacter.tsx` remains available for projects that call for a simpler SVG cartoon with shaded volume.
- Give background rooms perspective corners, a floor plane and converging lines. Ground characters and props on that plane with contact shadows. Keep foreground elements able to occlude them.
- Give phones, cards, furniture and signs visible side faces, top highlights and consistent light direction. Avoid placing flat rectangles over a dimensional room without thickness.
- Animate actions first: a hand reaching, turning a head, stepping, recoiling, picking up a prop. Keep idle motion subtle. Use smooth camera movement and an intentional close-up where it helps the story; avoid constant shake or zoom.
- For a Short, inspect full-size frames at the hook, every scene change and a character close-up. Watch motion at normal speed to catch sliding feet, stiff arms, flat characters, text occlusion and jerky camera moves.
- Review the rendered shot at normal playback speed. Check that the hands, gaze, and weight shifts stay smooth as the camera angle changes. See `tv-cartoon-animation.md`.
