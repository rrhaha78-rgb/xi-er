# TV-cartoon movement for narrative Shorts

Use this when the user asks for characters to move like a normal cartoon on TV. The character should act inside the scene rather than glide as a single still image.

- Keep the same character design across shots. Separate the character from backgrounds so limbs, head and face can be animated without moving the entire room.
- Block each beat with a readable action: notice, turn, reach, step, stop, react. Use different poses for those beats. Animate head, arms, legs and torso independently where visible.
- Give walking and running a repeating gait with foot placement and weight shift. Use small idle breathing or gaze changes when the character is otherwise still. Avoid motion for motion's sake.
- Let props meet hands, feet meet floors and foreground objects pass in front of the character when appropriate. Keep light direction, shadows, scale and perspective consistent across cuts.
- Use a close-up for the reaction, a wide shot to establish a new place, and a motivated cut for the next action. Keep zooms smooth and sparing; do not shake the camera constantly.
- Match sound to actions and transitions. Use narration with pauses, emphasis and changing tone; leave a beat for the viewer to absorb an important image.
- Check a few seconds at normal playback speed from the hook, each location change and a character action. Look for frozen poses, sliding feet, stiff joints, abrupt jumps, duplicate characters and mismatched lighting. Repair those before final render.
- Static paintings can serve as sets. A still image with a drifting camera alone does not satisfy this movement style.

## Cinema-style 3D movement

Treat the smoothness of the earlier clay test as a motion reference for both clay and textured cinematic 3D. The user's visual choice controls character design, materials, and lighting. It does not change the standard for body mechanics or camera timing.

Use actual 3D characters and sets for the user's cinema-cartoon reference. Keep arm and leg lengths fixed through poses, with connected joints, grounded feet and consistent scale. Animate the eyes before the head turns, let the torso follow, and give props a clear grip and release. Ease into and out of the action and let the character settle before the next beat.

Stage coverage around the action: establish where the character and prop are, cut to an insert when the prop matters, then return for the reaction. Keep the camera and lighting consistent across those angles. Review a rendered motion sample at playback speed before using the setup for the whole film. Reject stretched anatomy, sliding feet, disconnected hands and photo cutouts that clash with the set.

When the user wants to direct, keep shots independently editable and use their directions for performance, framing and timing. A short playable shot is enough to discuss those choices before committing a full render.
