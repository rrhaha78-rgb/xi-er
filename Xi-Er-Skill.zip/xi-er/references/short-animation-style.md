# Short animation style preference

References: https://www.youtube.com/shorts/LC8hYwUZ-kU ("Why the Second Draw Always Wins")
and the user's screenshots of "Levels of Pirate Cannonballs" and "The Job Nobody Wants in Japan"
(2026-11-05).
Additional reference: the user's 49-second screen recording,
`a local reference recording` (2026-11-07).
Apply when the user asks for a similar style;
adapt the pacing to the actual story and avoid copying the reference's plot or characters.

- The target is a **cohesive cartoon world**, with thick dark outlines on characters,
  props and room edges, simple color fills, modest shading, and perspective that gives the
  set depth. The pirate screenshot has deck planks, cannon, rigging and sea; the office
  screenshots have a corridor, desks, files, clock and button. Both use clear shapes and
  readable foreground objects. Avoid a photoreal or highly rendered background behind a
  flat SVG character: that mismatch appeared in the workshop and bedroom samples and did
  not meet the user's target.
- Use scene changes as storytelling: wide room view to establish place, character reaction,
  close-up of the object that matters (clock, phone, button), then a new angle or room when
  the action moves. Preserve the same outline, color and lighting treatment in every shot.
- Keep characters cute and instantly readable, with changing facial expressions, posing,
  body turns and interactions with props. Their animation should show intent and reaction.
- Make actions legible: a pose anticipates an event, the body or prop moves, then the face and
  surrounding characters react. Change expressions and silhouettes at story beats.
- Alternate establishing frames, closer character views, and reaction shots. Let camera position,
  framing, and depth change with the action rather than leaving one static composition throughout.
- Use deliberate zoom-ins for important expressions, reveals, and impacts. Ease into and out of
  each zoom, keep the subject framed clearly, and let foreground and background shift at different
  speeds with true perspective so the move has depth. Avoid abrupt digital scale jumps unless
  a sudden jolt is the joke.
- Make character and camera movement feel smooth: use eased acceleration and deceleration,
  continuous arcs between poses, and a short settle or follow-through after fast actions. Check
  the motion at normal playback speed so transitions do not stutter or snap unintentionally.
- Animate foreground props and background activity as well as the main character. Use parallax,
  shadows, light, and atmosphere to make the setting feel occupied.
- Coordinate sound effects, narration, and short on-screen emphasis words with the visible action.
  Keep the emphasis text readable in a vertical phone frame.
- The reference uses comic exaggeration and quick visual payoffs. Preserve clear cause and effect;
  do not turn every moment into constant frantic movement.

## Shot grammar from the 2026-11-07 recording

- Build an **entire illustrated place** before animating a character. Use a floor or ground plane,
  background architecture, cast shadows, and a distinct foreground prop. Keep outlines and shading
  consistent across every element. The reference cuts between a plaza at night, a close-up of a
  button, an interior-like abstract view, an outdoor crowd, and a face reaction, all in the same
  visual language. Make original settings and characters; do not trace or reuse its designs.
- Give each shot one visual question: *where are we? who acts? what object matters? what changed?*
  Use a wide view for geography, a medium view for an action, a tight prop insert for the cause,
  then a reaction or changed world for the effect. Cut when the answer changes. Do not keep a
  single illustrated panel on screen while only the camera zooms.
- Hold poses long enough to read. Animate the **action**, not constant idle motion: anticipation,
  hand/body movement, contact, short overshoot, settle, then a readable reaction. On a held shot,
  use only a subtle camera drift and one small bit of background life.
- Move the camera with an eased pan or push; let foreground, subject and background travel at
  different speeds. A prop insert can begin on a moving hand and end on the prop. Reserve abrupt
  cuts or camera jolts for actual story beats.
- Use simple face acting: eyebrow angle, eye shape, mouth shape and head tilt change together.
  A concerned face needs a held beat; a surprise can snap quickly then settle. Avoid sliding
  an otherwise fixed character around as a substitute for acting.
- Keep captions to a few spoken words at a time, large white type with dark outline, away from
  the right-hand social controls and bottom UI. Do not replicate the reference's text or layout
  frame-for-frame.
- Sync foley to visible contact (button press, footstep, door, phone); leave room for the soft
  spoken line. Build the sound arc as ambience → cue → action → reaction → quiet beat.
- Use `src/fx/cartoonStory.ts` in the videokit template for eased shot camera positions and
  bounded acting beats. It is a helper, not a character or scene asset.

For a future video, validate the motion by watching the animatic and final cut in real time.
Still frames alone cannot show whether the acting, camera, and timing work.
