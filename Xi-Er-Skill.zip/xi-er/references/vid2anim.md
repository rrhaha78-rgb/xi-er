# Local motion capture with vid2anim

[vid2anim](https://github.com/mehulcode12/vid2anim) supplies motion from footage of a person. Use it for a shot with an available performance clip, such as a run, fall, or turn. Blender still handles character appearance, staging, props, facial acting, lighting, and rendering.

## Workspace setup

The checkout is `work/vid2anim` relative to the workspace root. It uses its own Python 3.12 environment. Run from that checkout so the tool keeps its data there.

```powershell
Set-Location work/vid2anim
# Only needed if the local environment has not been created.
py -3.12 -m venv .venv
& ./.venv/Scripts/python.exe -m pip install -e . 'mediapipe==0.10.21'
```

Start with MediaPipe on CPU. The RTX remains available for Blender and video encoding. Check disk space and model requirements before opting into a larger engine. This workflow uses no Gemini API or billing.

## Use a performance in a shot

1. Choose a short clip with the performer in view, including hands and feet where relevant. Use a fixed camera and a clear silhouette when possible.
2. Run `& ./.venv/Scripts/vid2anim.exe run --input <clip.mp4> --model <rigged-character.glb> --engine mediapipe --output <animated.glb>` from the checkout. Use `inspect <rigged-character.glb>` to check the detected skeleton before a long job. Use `extract` and `retarget` separately to reuse one performance on multiple rigs.
3. Import the animated GLB into a separate Blender scene or collection first. Check the action's orientation, scale, frame rate, starting pose, foot planting, and hand paths. Match the action to the production timeline before adding it to a shot.
4. Treat the current Snow/CloudRig character as a separate retargeting step. Test a few seconds on a copy, map the captured motion to the production controls where required, then bake and review. Use a mapped humanoid intermediary or the existing pose animation when automatic mapping fails. Use custom animation for Pokémon, facial expressions, finger poses, and hand-to-prop contact.

The CLI and GLB route works without enabling a Blender add-on. If the portable Blender installation reports that its NumPy DLL path is too long, launch the same Blender installation through a temporary short drive mapping.

For direct retargeting in Blender, follow the upstream [Blender add-on guide](https://github.com/mehulcode12/vid2anim#-blender-3d-bridge-add-on) and test it in a disposable scene first.
